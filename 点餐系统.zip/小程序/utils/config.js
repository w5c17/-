module.exports = {
  url: 'http://2892t80h18.oicp.vip/api/'
}