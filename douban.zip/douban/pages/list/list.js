import {network} from "../../utils/network.js"
Page({

  data: {

  },

  onLoad: function (options) {
    var that=this;
    var type=options.type;
    that.setData({
      type:type
    })
    var title="";
    wx.showLoading({
      title: '正在加载中'
    })
    //请求电影
    if(type=="movie"){
      network.getMovieList({
        success: function (items){
          that.setData({
            items: items
          })
          wx.hideLoading();
        },
        count:1000
      });
      title = "电影";
    }
    //请求电视剧
    else if(type=="tv"){
      network.getTvList({
        success: function (items){
          that.setData({
            items: items
          })
          wx.hideLoading();
        },
        count: 1000
      });
      title = "电视剧";
    }
    //请求综艺
    else {
      network.getShowList({
        success: function (items) {
          that.setData({
            items: items
          })
          wx.hideLoading();
        },
        count: 1000
      });
      title = "综艺";
    }
    wx.setNavigationBarTitle({
      title: title
    })
  },

})