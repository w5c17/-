import {network} from "../../utils/network.js"
Page({
  data: {

  },

  onLoad: function (options) {
    var that=this
    //请求电影
    network.getMovieList({
      success:function(movies){
        that.setData({
          movies:movies
        })
        console.log(movies)
      }
    });
    //请求电视剧
    network.getTvList({
      success: function (tvs) {
        that.setData({
          tvs: tvs
        })
      }
    });
    //请求综艺
    network.getShowList({
      success: function (shows) {
        that.setData({
          shows: shows
        })
      }
    });
  },

})
