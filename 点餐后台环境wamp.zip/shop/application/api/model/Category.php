<?php
namespace app\api\model;

use think\Model;

class Category extends Model
{

}