import {network} from "../../utils/network.js"
Page({

  data: {

  },

  onLoad: function (options) {
    var that=this;
    var type=options.type;
    var id=options.id;
    that.setData({
      id:id,
      type:type
    })
    network.getItemDetail({
      type:type,
      id:id,
      success:function(item){
        var genres=item.genres;
        item.genres=genres;
        var actors=item.actors;
        var actorName=[];
        if(actors.length>3){
          actors=actors.slice(0,3);
        }
        for(var index=0;index<actors.length;index++){
          var actor=actors[index];
          actorName.push(actor.name);
        }
        actorName=actorName.join("/");
        if(item.directors[0]!=undefined){
          var directors = item.directors[0].name;
          var authors = directors + "(导演)/" + actorName;
        }
        else{
          var authors = actorName;
        }
        item.authors=authors;
        that.setData({
         item:item
       })
      }
    });
    network.getItemTags({
      type:type,
      id:id,
      success:function(tags){
        that.setData({
          tags:tags
        })
      }
    });
    network.getItemComments({
      type:type,
      id:id,
      success:function(data){
        var totalComments=data.total;
        var comments=data.interests;
        that.setData({
          totalComments:totalComments,
          comments:comments
        })
      }
    })
  },
  onShow:function(){
    wx.pageScrollTo({
      scrollTop: 0,
    })
  }
})